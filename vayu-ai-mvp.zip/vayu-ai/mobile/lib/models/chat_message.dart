class ChatMessage {
  ChatMessage({
    required this.role,
    required this.content,
    required this.timestamp,
    this.translatedContent,
  });

  final String role; // 'user' | 'assistant'
  final String content;
  final DateTime timestamp;
  // Set when the user's preferred language != 'en'. First line is the
  // translation, second line (if present) is the romanized transliteration.
  final String? translatedContent;

  factory ChatMessage.user(String content) => ChatMessage(
        role: 'user',
        content: content,
        timestamp: DateTime.now(),
      );

  factory ChatMessage.assistant(String content, {String? translatedContent}) =>
      ChatMessage(
        role: 'assistant',
        content: content,
        timestamp: DateTime.now(),
        translatedContent: translatedContent,
      );

  ChatMessage copyWith({String? translatedContent}) => ChatMessage(
        role: role,
        content: content,
        timestamp: timestamp,
        translatedContent: translatedContent ?? this.translatedContent,
      );
}
